<?php
session_start();

if (isset($_SESSION['first_name'])) {
    
    include 'add_notice.php';
} elseif (isset($_SESSION['username']) && isset($_SESSION['id'])) {
    
    include 'view_notices.php';
} else {
    echo "Access denied. Please login.";
}
?>
