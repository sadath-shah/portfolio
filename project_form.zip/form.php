<?php include_once("navbar.php"); ?>

<title>Student Registration Form</title>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js"></script>

<style>
  body {
    font-family: Arial, sans-serif;
    background-image: url('https://images.pexels.com/photos/5212345/pexels-photo-5212345.jpeg');
    background-size: cover;
    background-attachment: fixed;
    background-repeat: no-repeat;
    background-position: center;
    margin: 0;
    padding: 0;
    color: #333;
  } 

  .error {
    color: red;
    font-size: 0.9em;
  }

  .container {
    background-color: #ffffff;
    padding: 20px;
    max-width: 800px;
    margin: 100px auto 50px auto;
    border: 1px solid #0b0000;
    border-radius: 10px;
  }

  h2, h3 {
    text-align: center;
    color: #333;
    margin-bottom: 20px;
  }

  .form-group {
    display: flex;
    align-items: center;
    margin-bottom: 15px;
  }

  .form-group label {
    width: 250px;
    font-weight: bold;
  }

  .form-group input,
  .form-group textarea {
    flex: 1;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 5px;
  }

  .form-group-row {
    display: flex;
    gap: 10px;
    margin-bottom: 15px;
  }

  .form-group-row input {
    flex: 1;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 5px;
  }

  .form-radio {
    display: flex;
    gap: 15px;
    margin-bottom: 15px;
    align-items: center;
  }

  .terms {
    background-color: #444;
    color: #fff;
    padding: 10px;
    margin-top: 20px;
    border-radius: 5px;
  }

  button {
    margin-top: 20px;
    padding: 10px 20px;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 10px;
    cursor: pointer;
  }

  button:hover {
    background-color: rgb(44, 47, 190);
  }

  footer {
    background-color: rgb(236, 242, 247);
    color: black;
    text-align: center;
    padding: 15px;
    box-shadow: 0 -2px 8px rgba(0, 0, 0, 0.05);
  }

  .error-msg {
    margin-top: 5px;
    display: block;
  }
</style>

<div class="container">
  <h2>Student Registration Form</h2>
  <form action="submit.php" method="post" enctype="multipart/form-data" id="srf">
    <div class="form-group-row">
      <input type="text" placeholder="First Name" name="firstname" required />
      <input type="text" placeholder="Last Name" name="lastname" required />
    </div>

    <div class="form-group">
      <label for="dob">Date of Birth:</label>
      <input type="date" name="dob" id="dob" required />
    </div>

    <div class="form-group">
      <label>Gender:</label>
      <div class="form-radio">
        <label><input type="radio" name="gender" value="Male" /> Male</label>
        <label><input type="radio" name="gender" value="Female" /> Female</label>
      </div>
    </div>

    <div class="form-group">
      <label for="grade">Grade:</label>
      <input type="text" name="grade" id="grade" required />
    </div>

    <div class="form-group">
      <label for="languages">Languages Spoken:</label>
      <input type="text" name="languages" id="languages" required />
    </div>

    <div class="form-group">
      <label for="details1">Details of Siblings:</label>
      <input type="text" placeholder="1." name="details1" id="details1" />
    </div>

    <div class="form-group">
      <label for="details2">&nbsp;</label>
      <input type="text" placeholder="2." name="details2" id="details2" />
    </div>

    <div class="form-group">
      <label for="student_photo">Upload Student Photo:</label>
      <input type="file" name="student_photo" id="student_photo" accept="image/*" />
    </div>

    <h3>Parent’s Information:</h3>

    <div class="form-group">
      <label for="fathers_name">Father's Name:</label>
      <input type="text" name="fathers_name" />
    </div>

    <div class="form-group">
      <label for="fathers_qualification">Father's Qualification:</label>
      <input type="text" name="fathers_qualification" />
    </div>

    <div class="form-group">
      <label for="fathers_email">Father's Email:</label>
      <input type="text" name="fathers_email" />
    </div>

    <div class="form-group">
      <label for="fathers_phn_no">Father's Phone No:</label>
      <input type="number" name="fathers_phn_no" />
    </div>

    <div class="form-group">
      <label for="fathers_occupation">Father's Occupation:</label>
      <input type="text" name="fathers_occupation" />
    </div>

    <div class="form-group">
      <label for="mothers_name">Mother's Name:</label>
      <input type="text" name="mothers_name" />
    </div>

    <div class="form-group">
      <label for="mothers_qualification">Mother's Qualification:</label>
      <input type="text" name="mothers_qualification" />
    </div>

    <div class="form-group">
      <label for="mothers_email">Mother's Email:</label>
      <input type="text" name="mothers_email" />
    </div>

    <div class="form-group">
      <label for="mothers_phn_no">Mother's Phone No:</label>
      <input type="number" name="mothers_phn_no" />
    </div>

    <div class="form-group">
      <label for="mothers_occupation">Mother's Occupation:</label>
      <input type="text" name="mothers_occupation" />
    </div>

    <div class="form-group-row">
      <input type="password" placeholder="New Password" name="password" required />
      <input type="password" placeholder="Confirm Password" name="confirm_password" required />
    </div>

    <div class="form-group">
      <label for="address">Address:</label>
      <textarea name="address" rows="3" placeholder="Residential Address"></textarea>
    </div>

    <div class="form-group">
      <label>Payment Details:</label>
      <div class="form-radio">
        <label><input type="radio" name="payment" value="cash" /> Cash</label>
        <label><input type="radio" name="payment" value="check" /> Check</label>
        <label><input type="radio" name="payment" value="card" /> Card</label>
      </div>
    </div>

    <div class="terms">
      <strong>Terms and Conditions:</strong>
      <p>1. I/we certify that the above information provided by me/us is correct.</p>
      <p>2. I undertake to submit all the documents in original for verification.</p>
    </div>

    <div class="text-center mt-4">
      <button type="submit" class="btn btn-primary">Submit</button>
    </div>

    <div class="text-center mt-3">
      <p style="margin-bottom: 6px;">Already have an account?</p>
      <a href="login.php" class="btn btn-outline-secondary">Login Here</a>
    </div>
  </form>
</div>

<footer>
  <p>2025 School Name. All Rights Reserved. For more information contact +91 9030145367 | E.mail: sadathshah01@gmail.com</p>
</footer>

<script>
  $(document).ready(function () {
    $("#srf").validate({
      rules: {
        firstname: { required: true, minlength: 2 },
        lastname: { required: true, minlength: 2 },
        dob: { required: true, date: true },
        gender: { required: true },
        grade: { required: true },
        languages: { required: true },
        details1: { required: true },
        details2: { required: true },
        student_photo: { required: true, extension: "jpg|jpeg|png" },
        fathers_name: { required: true, minlength: 2 },
        fathers_email: { required: true, email: true },
        fathers_phn_no: { required: true, digits: true, minlength: 10, maxlength: 10 },
        fathers_qualification: { required: true },
        fathers_occupation: { required: true },
        mothers_name: { required: true, minlength: 2 },
        mothers_email: { required: true, email: true },
        mothers_phn_no: { required: true, digits: true, minlength: 10, maxlength: 10 },
        mothers_qualification: { required: true },
        mothers_occupation: { required: true },
        password: { required: true, minlength: 6 },
        confirm_password: { required: true, equalTo: "[name='password']" },
        address: { required: true },
        payment: { required: true },
      },
      messages: {
        student_photo: {
          required: "Please upload a photo",
          extension: "Only image files are allowed (jpg, jpeg, png)",
        },
      },
      errorElement: "div",
      errorPlacement: function (error, element) {
        error.addClass("text-danger mt-1");
        if (element.attr("type") === "radio") {
          error.insertAfter(element.closest(".form-radio"));
        } else {
          error.insertAfter(element);
        }
      },
      submitHandler: function (form) {
        form.submit();
      },
    });
  });
</script>
