<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>Success</title>
    
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
  </head>
  <body
    class="bg-light d-flex justify-content-center align-items-center"
    style="width: 100vw; height: 100vh"
  >
    <div class="text-center border p-4 rounded bg-white shadow">
      <h4 class="text-success">✅ Data Inserted Successfully</h4>
      <p>Your data has been saved.</p>
      <a href="login.php" class="btn btn-primary">Login</a>
    </div>
  </body>
</html>
