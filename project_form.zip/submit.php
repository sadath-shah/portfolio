<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $conn = new mysqli('localhost', 'root', '', 'srf');
  if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

  $hashedPassword = password_hash($_POST['password'], PASSWORD_DEFAULT);

  
  $image_name = '';
  if (is_uploaded_file($_FILES['student_photo']['tmp_name'])) {
    $upload_dir = 'uploads/';
    $image_name = time() . '_' . basename($_FILES['student_photo']['name']);
    $target_path = $upload_dir . $image_name;

    move_uploaded_file($_FILES['student_photo']['tmp_name'], $target_path);
  }

  $stmt = $conn->prepare("INSERT INTO student_registration_form 
    (firstname, lastname, dob, gender, grade, languages, details1, details2, profile_image, fathers_name, fathers_qualification, fathers_email, fathers_phn_no, fathers_occupation, mothers_name, mothers_qualification, mothers_email, mothers_phn_no, mothers_occupation, password, address, payment) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

  $stmt->bind_param("ssssssssssssssssssssss", 
    $_POST['firstname'], $_POST['lastname'], $_POST['dob'], $_POST['gender'], $_POST['grade'], $_POST['languages'],
    $_POST['details1'], $_POST['details2'], $image_name,
    $_POST['fathers_name'], $_POST['fathers_qualification'], $_POST['fathers_email'], $_POST['fathers_phn_no'], $_POST['fathers_occupation'],
    $_POST['mothers_name'], $_POST['mothers_qualification'], $_POST['mothers_email'], $_POST['mothers_phn_no'], $_POST['mothers_occupation'],
    $hashedPassword, $_POST['address'], $_POST['payment']
  );

  $stmt->execute();
  $stmt->close();
  $conn->close();

  header("Location: thankyou.php");
  exit();
}
?>
