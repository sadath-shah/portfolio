<?php
include_once("navbar.php");

?>


  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-image: url('https://images.unsplash.com/photo-1503676382389-4809596d5290');
      background-size: cover;
      background-attachment: fixed;
      background-repeat: no-repeat;
      background-position: center;
      margin: 0;
      padding-top: 80px;
      color: #333;
    
    }

    .admissions-container {
      background-color: rgba(255, 255, 255, 0.95);
      max-width: 900px;
      margin: 40px auto;
      padding: 40px;
      border-radius: 15px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    }

    .admissions-container h1 {
      font-weight: bold;
      color: #004080;
      margin-bottom: 25px;
    }

    .admissions-container p {
      font-size: 1.1rem;
      line-height: 1.7;
      color: #444;
    }

    .btn-apply {
      background-color: #004080;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 8px;
      font-size: 1rem;
      margin-top: 20px;
      text-decoration: none;
    }

    .btn-apply:hover {
      background-color: #003060;
    }
    footer {
        background-color: rgb(236, 242, 247);
        color: black;
        text-align: center;
        padding-top:5px;
        padding: 15px;
        margin-top: 122px;
        box-shadow: 0 -2px 8px rgba(0, 0, 0, 0.05);
      }
    
  </style>


  <div class="admissions-container">
    <h1>Admissions Open!</h1>
    <p>
      We are now accepting applications for the upcoming academic year! Our school provides an ideal learning environment where children are encouraged to explore, learn, and grow.
    </p>
    <p>
      Whether you're looking for strong academic programs, dedicated faculty, or an inclusive atmosphere that supports every student’s success, Our School is the perfect place to begin your journey.
    </p>
    <p>
      Admissions are open from June to August. Hurry and secure your child’s future by applying today.
    </p>
    <a class="btn-apply" href="form.php">Apply Now</a>
  </div>
  <footer>
      <p>
        2025 School Name. All Rights Reserved. For more information contact +91 9030145367
        E.mail: sadathshah01@gmail.com
      </p>
    </footer>

  
