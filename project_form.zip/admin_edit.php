<?php
session_start();
include 'admin_connect.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$stmt = $conn->prepare("SELECT * FROM student_registration_form WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "<h4 class='text-danger p-3'>No student found with ID $id</h4>";
    exit;
}

$student = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fields = [
        'firstname', 'lastname', 'dob', 'gender', 'grade', 'languages', 'details1', 'details2',
        'fathers_name', 'fathers_qualification', 'fathers_email', 'fathers_phn_no', 'fathers_occupation',
        'mothers_name', 'mothers_qualification', 'mothers_email', 'mothers_phn_no', 'mothers_occupation',
        'address', 'payment'
    ];

    $data = [];
    foreach ($fields as $field) {
        $data[$field] = $_POST[$field] ?? '';
    }

    $sql = "UPDATE student_registration_form SET 
        firstname=?, lastname=?, dob=?, gender=?, grade=?, languages=?, details1=?, details2=?,
        fathers_name=?, fathers_qualification=?, fathers_email=?, fathers_phn_no=?, fathers_occupation=?,
        mothers_name=?, mothers_qualification=?, mothers_email=?, mothers_phn_no=?, mothers_occupation=?,
        address=?, payment=? WHERE id=?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "ssssssssssssssssssssi",
        $data['firstname'], $data['lastname'], $data['dob'], $data['gender'], $data['grade'],
        $data['languages'], $data['details1'], $data['details2'],
        $data['fathers_name'], $data['fathers_qualification'], $data['fathers_email'], $data['fathers_phn_no'], $data['fathers_occupation'],
        $data['mothers_name'], $data['mothers_qualification'], $data['mothers_email'], $data['mothers_phn_no'], $data['mothers_occupation'],
        $data['address'], $data['payment'], $id
    );

    if ($stmt->execute()) {
        header("Location: admin_student_records.php?success=1");
        exit();
    } else {
        $error = "Failed to update student record.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Student</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4 mb-5">
  <h2 class="text-center mb-4">Edit Student Record</h2>

  <?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <form method="POST">
    <div class="row g-3">
      <?php
      function input($label, $name, $value, $type = 'text') {
          echo "<div class='col-md-6'>
                  <label class='form-label'>$label</label>
                  <input type='$type' name='$name' class='form-control' value='" . htmlspecialchars($value) . "'>
                </div>";
      }
      function textarea($label, $name, $value) {
          echo "<div class='col-md-6'>
                  <label class='form-label'>$label</label>
                  <textarea name='$name' class='form-control'>" . htmlspecialchars($value) . "</textarea>
                </div>";
      }

      input("First Name", "firstname", $student['firstname']);
      input("Last Name", "lastname", $student['lastname']);
      input("Date of Birth", "dob", $student['dob'], 'date');
      input("Gender", "gender", $student['gender']);
      input("Grade", "grade", $student['grade']);
      input("Languages", "languages", $student['languages']);
      textarea("Details 1", "details1", $student['details1']);
      textarea("Details 2", "details2", $student['details2']);
      input("Father's Name", "fathers_name", $student['fathers_name']);
      input("Father's Qualification", "fathers_qualification", $student['fathers_qualification']);
      input("Father's Email", "fathers_email", $student['fathers_email']);
      input("Father's Phone", "fathers_phn_no", $student['fathers_phn_no']);
      input("Father's Occupation", "fathers_occupation", $student['fathers_occupation']);
      input("Mother's Name", "mothers_name", $student['mothers_name']);
      input("Mother's Qualification", "mothers_qualification", $student['mothers_qualification']);
      input("Mother's Email", "mothers_email", $student['mothers_email']);
      input("Mother's Phone", "mothers_phn_no", $student['mothers_phn_no']);
      input("Mother's Occupation", "mothers_occupation", $student['mothers_occupation']);
      textarea("Address", "address", $student['address']);
      input("Payment", "payment", $student['payment']);
      ?>

      <div class="col-12 mt-4">
        <button type="submit" class="btn btn-success">Update Record</button>
        <a href="admin_student_records.php" class="btn btn-secondary ms-2">← Back to All Records</a>
      </div>
    </div>
  </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
