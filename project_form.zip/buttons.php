<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Student Profile</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

  <style>
    body {
      font-family: Arial, sans-serif;
      padding-top: 80px;
      background-color: #f9f9f9;
    }

    .navbar-brand img {
      border-radius: 4px;
    }

    .profile-container {
      max-width: 900px;
      margin: auto;
      background-color: #fff;
      border-radius: 10px;
      padding: 30px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .profile-img {
      width: 150px;
      height: 150px;
      object-fit: cover;
      border-radius: 50%;
    }

    .profile-details p {
      margin-bottom: 8px;
    }

    .back-btn {
      margin-top: 20px;
    }

    @media (max-width: 768px) {
      .d-flex {
        flex-direction: column !important;
        text-align: center;
      }

      .profile-details {
        margin-top: 20px;
      }
    }
  </style>
</head>
<body>

<?php
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$profileImageFilename = !empty($_SESSION['pfp']) ? htmlspecialchars($_SESSION['pfp']) : null;
$profileImagePath = $profileImageFilename ? "uploads/" . $profileImageFilename : 'https://cdn-icons-png.flaticon.com/512/3135/3135715.png';
?>

<nav class="navbar navbar-expand-lg bg-white shadow-sm fixed-top">
  <div class="container-fluid px-4">
    <a class="navbar-brand d-flex align-items-center fw-bold" href="#">
      <img
        src="https://db0dce98.delivery.rocketcdn.me/en/files/2023/05/django1.jpg"
        alt="Logo"
        width="40"
        height="34"
        class="d-inline-block align-text-top me-2"
      />
      School Name
    </a>

    <div class="ms-auto d-flex align-items-center">
      <span class="me-3">Hello, <?= htmlspecialchars($_SESSION['username']) ?>!</span>

      <div class="dropdown">
        <a
          href="#"
          class="d-flex align-items-center text-decoration-none dropdown-toggle"
          id="userDropdown"
          data-bs-toggle="dropdown"
          aria-expanded="false"
        >
          <img
            src="<?= $profileImagePath ?>"
            alt="Profile Image"
            width="40"
            height="40"
            class="rounded-circle me-3"
            style="object-fit: cover;"
            onerror="this.onerror=null;this.src='https://cdn-icons-png.flaticon.com/512/3135/3135715.png';"
          />
        </a>

        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
          <li>
            <a class="dropdown-item" href="edit.php?id=<?= $_SESSION['id'] ?>">Update</a>
          </li>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
        </ul>
      </div>
    </div>
  </div>
</nav>


<div class="profile-container mt-5">
  <h3 class="text-center mb-4">Your Profile</h3>

  <?php
    $conn = new mysqli('localhost', 'root', '', 'srf');
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

    $id = $_SESSION['id'];
    $stmt = $conn->prepare("SELECT * FROM student_registration_form WHERE id = ?");
    $stmt->bind_param("i", $id);  
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()):
      $profileSrc = !empty($row['profile_image']) ? "uploads/" . htmlspecialchars($row['profile_image']) : "https://cdn-icons-png.flaticon.com/512/3135/3135715.png";
  ?>
    <div class="d-flex align-items-center gap-4">
      <div>
        <img src="<?= $profileSrc ?>" alt="Profile Photo" class="profile-img" />
      </div>
      <div class="profile-details">
        <p><strong>First Name:</strong> <?= htmlspecialchars($row['firstname']); ?></p>
        <p><strong>Last Name:</strong> <?= htmlspecialchars($row['lastname']); ?></p>
        <p><strong>Date of Birth:</strong> <?= htmlspecialchars($row['dob']); ?></p>
        <p><strong>Gender:</strong> <?= htmlspecialchars($row['gender']); ?></p>
        <p><strong>Grade:</strong> <?= htmlspecialchars($row['grade']); ?></p>
        <p><strong>Languages:</strong> <?= htmlspecialchars($row['languages']); ?></p>
        <p><a href="view.php?id=<?= $row['id']; ?>" class="btn btn-primary btn-sm mt-2"><i class="fas fa-eye me-1"></i> View Full Record</a></p>
        <p><a href="edit.php?id=<?= $row['id']; ?>" class="btn btn-warning btn-sm mt-2"><i class="fas fa-edit me-1"></i> Edit Record</a></p>
      </div>
    </div>
  <?php else: ?>
    <p class="text-center text-danger">No data found.</p>
  <?php endif;

    $stmt->close();
    $conn->close();
  ?>

  <div class="text-center back-btn">
    <a href="dashboard.php" class="btn btn-secondary">← Back to Dashboard</a>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
