<?php
include 'notice_db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = intval($_POST['id']);

    $stmt = $conn->prepare("DELETE FROM notices WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: add_notice.php");
        exit();
    } else {
        echo "Error deleting notice.";
    }

    $stmt->close();
    $conn->close();
}
?>
