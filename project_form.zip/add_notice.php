<?php
include 'notice_db.php';

// Toggle status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_status'])) {
  $id = intval($_POST['notice_id']);
  $current = $_POST['current_status'];
  $new_status = ($current === 'Active') ? 'Inactive' : 'Active';

  $stmt = $conn->prepare("UPDATE notices SET status = ? WHERE id = ?");
  $stmt->bind_param("si", $new_status, $id);
  $stmt->execute();
  $stmt->close();
}

// Delete notice
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_notice'])) {
  $id = intval($_POST['notice_id']);

  $stmt = $conn->prepare("DELETE FROM notices WHERE id = ?");
  $stmt->bind_param("i", $id);
  $stmt->execute();
  $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Add Notice</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">

  <div class="container mt-5">
    <h2 class="mb-4">Add New Notice</h2>
    <form action="insert_notice.php" method="POST">
      <div class="mb-3">
        <label for="title" class="form-label">Notice Title</label>
        <input type="text" name="title" id="title" class="form-control" required>
      </div>

      <div class="mb-3">
        <label for="content" class="form-label">Notice Content</label>
        <textarea name="content" id="content" rows="5" class="form-control" required></textarea>
      </div>

      <div class="mb-3">
        <label for="status" class="form-label">Status</label>
        <select name="status" id="status" class="form-select" required>
          <option value="Active">Active</option>
          <option value="Inactive">Inactive</option>
        </select>
      </div>

      <button type="submit" class="btn btn-primary">Post Notice</button>
    </form>
  </div>

  <!-- Notice Table -->
  <div class="container mt-5">
    <h3>All Notices</h3>
    <?php
    $result = $conn->query("SELECT * FROM notices ORDER BY created_at DESC");
    if ($result->num_rows > 0):
    ?>
    <table class="table table-bordered mt-3">
      <thead class="table-dark">
        <tr>
          <th>Title</th>
          <th>Status</th>
          <th>Created At</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
          <td><?php echo htmlspecialchars($row['title']); ?></td>
          <td>
            <form method="POST" style="display:inline;">
              <input type="hidden" name="notice_id" value="<?php echo $row['id']; ?>">
              <input type="hidden" name="current_status" value="<?php echo $row['status']; ?>">
              <button type="submit" name="toggle_status" class="btn btn-sm <?php echo $row['status'] === 'Active' ? 'btn-success' : 'btn-secondary'; ?>">
                <?php echo $row['status']; ?>
              </button>
            </form>
          </td>
          <td><?php echo $row['created_at']; ?></td>
          <td>
            <form method="POST" onsubmit="return confirm('Are you sure you want to delete this notice?');" style="display:inline;">
              <input type="hidden" name="notice_id" value="<?php echo $row['id']; ?>">
              <button type="submit" name="delete_notice" class="btn btn-sm btn-danger" title="Delete Notice">
                <i class="bi bi-trash-fill"></i>
              </button>
            </form>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
    <?php else: ?>
      <p>No notices posted yet.</p>
    <?php endif; ?>
  </div>

  <div class="text-center back-btn mt-4">
    <a href="admin_dashboard.php" class="btn btn-secondary">← Back to Dashboard</a>
  </div>

</body>
</html>
