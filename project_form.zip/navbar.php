<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>School Navbar</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet" />

  <style>
    body {
      margin: 0;
      padding: 0;
    }

    .navbar-brand img {
      border-radius: 4px;
    }

    .navbar .btn {
      font-weight: 500;
    }
  </style>
</head>

<body>

  <nav class="navbar navbar-expand-lg bg-white shadow-sm fixed-top">
    <div class="container-fluid px-4">
      <a class="navbar-brand d-flex align-items-center fw-bold" href="homepage.php">
        <img
          src="https://db0dce98.delivery.rocketcdn.me/en/files/2023/05/django1.jpg"
          alt="Logo"
          width="40"
          height="34"
          class="d-inline-block align-text-top me-2"
        />
        School Name
      </a>

      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse justify-content-between" id="navbarContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="btn btn-outline-primary mx-1" href="homepage.php">Home</a>
          </li>

          <li class="nav-item">
            <a class="btn btn-outline-primary mx-1" href="https://www.google.com">Link</a>
          </li>

          <li class="nav-item dropdown">
            <div class="dropdown">
              <a class="btn btn-outline-primary dropdown-toggle mx-1" href="#" id="moreDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                More
              </a>
              <ul class="dropdown-menu" aria-labelledby="moreDropdown">
                <li><a class="dropdown-item" href="aboutus.php">About Us</a></li>
                <li><a class="dropdown-item" href="addmisions.php">Admissions</a></li>
                <li><a class="dropdown-item" href="#">Contact</a></li>
              </ul>
            </div>
          </li>
        </ul>

        <div class="d-flex">
          <a class="btn btn-outline-primary me-2" href="form.php">Register</a>

          
          <div class="dropdown">
            <a class="btn btn-outline-primary dropdown-toggle" href="#" role="button" id="loginDropdown" data-bs-toggle="dropdown" aria-expanded="false">
              Login
            </a>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="loginDropdown">
              <li><a class="dropdown-item" href="admin_login.php">Admin Login</a></li>
              <li><a class="dropdown-item" href="login.php">Student Login</a></li>
            </ul>
          </div>
        </div>

      </div>
    </div>
  </nav>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
