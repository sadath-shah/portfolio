<?php
include 'notice_db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    $status = $_POST['status'];

    if (!empty($title) && !empty($content) && !empty($status)) {
        $stmt = $conn->prepare("INSERT INTO notices (title, content, status) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $title, $content, $status);

        if ($stmt->execute()) {
            echo "<script>alert('Notice added successfully!'); window.location.href = 'notice_board.php';</script>";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "All fields are required.";
    }

    $conn->close();
} else {
    echo "Invalid request.";
}
?>
