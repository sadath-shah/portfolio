// document.addEventListener("DOMContentLoaded", function () {
//   const form = document.querySelector("form");

//   form.addEventListener("submit", function (e) {
//     let errors = [];

//     const nameRegex = /^[a-zA-Z\s]+$/;
//     const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
//     const phoneRegex = /^\d{10}$/;

//     const firstName = form.firstname.value.trim();
//     const lastName = form.lastname.value.trim();

//     if (!firstName || !nameRegex.test(firstName)) {
//       errors.push("Please enter a valid First Name (letters only).");
//     }

//     if (!lastName || !nameRegex.test(lastName)) {
//       errors.push("Please enter a valid Last Name (letters only).");
//     }

//     if (!form.dob.value.trim()) {
//       errors.push("Please enter Date of Birth.");
//     }

//     if (!form.grade.value.trim()) {
//       errors.push("Please enter Grade.");
//     }

//     if (!form.languages.value.trim()) {
//       errors.push("Please enter Languages Spoken.");
//     }

//     const password = form.password.value.trim();
//     const confirmPassword = form.confirm_password.value.trim();

//     if (password.length < 8) {
//       errors.push("Password must be at least 8 characters long.");
//     }

//     if (password !== confirmPassword) {
//       errors.push("Passwords do not match.");
//     }

//     const genderSelected = [...form.gender].some((radio) => radio.checked);
//     if (!genderSelected) {
//       errors.push("Please select a gender.");
//     }

//     const paymentSelected = [...form.payment].some((radio) => radio.checked);
//     if (!paymentSelected) {
//       errors.push("Please select a payment method.");
//     }

//     const fatherEmail = form.fathers_email.value.trim();
//     const fatherPhone = form.fathers_phn_no.value.trim();

//     if (fatherEmail && !emailRegex.test(fatherEmail)) {
//       errors.push("Invalid Father's Email format.");
//     }

//     if (fatherPhone && !phoneRegex.test(fatherPhone)) {
//       errors.push("Father's Phone Number must be 10 digits.");
//     }

//     const motherEmail = form.mothers_email.value.trim();
//     const motherPhone = form.mothers_phn_no.value.trim();

//     if (motherEmail && !emailRegex.test(motherEmail)) {
//       errors.push("Invalid Mother's Email format.");
//     }

//     if (motherPhone && !phoneRegex.test(motherPhone)) {
//       errors.push("Mother's Phone Number must be 10 digits.");
//     }

//     if (errors.length > 0) {
//       alert(errors.join("\n"));
//       e.preventDefault();
//     }
//   });
// });
$(document).ready(function () {
  $("#srf").validate({
    rules: {
      firstname: {
        required: true,
        minlength: 2,
      },
      lastname: {
        required: true,
        minlength: 2,
      },
      dob: {
        required: true,
        date: true,
      },
      gender: {
        required: true,
      },
      grade: {
        required: true,
      },
      languages: {
        required: true,
      },
      fathers_email: {
        email: true,
      },
      fathers_phn_no: {
        digits: true,
        minlength: 10,
        maxlength: 10,
      },
      mothers_email: {
        email: true,
      },
      mothers_phn_no: {
        digits: true,
        minlength: 10,
        maxlength: 10,
      },
      password: {
        required: true,
        minlength: 6,
      },
      confirm_password: {
        required: true,
        equalTo: "[name='password']",
      },
      address: {
        required: true,
      },
      payment: {
        required: true,
      },
    },

    messages: {
      firstname: {
        required: "Please enter your first name",
        minlength: "At least 2 characters",
      },
      lastname: {
        required: "Please enter your last name",
        minlength: "At least 2 characters",
      },
      dob: {
        required: "Please enter your date of birth",
      },
      gender: {
        required: "Please select gender",
      },
      grade: {
        required: "Please enter grade",
      },
      languages: {
        required: "Please enter languages",
      },
      fathers_email: {
        email: "Enter a valid email address",
      },
      fathers_phn_no: {
        digits: "Enter a valid 10-digit phone number",
        minlength: "Must be exactly 10 digits",
        maxlength: "Must be exactly 10 digits",
      },
      mothers_email: {
        email: "Enter a valid email address",
      },
      mothers_phn_no: {
        digits: "Enter a valid 10-digit phone number",
        minlength: "Must be exactly 10 digits",
        maxlength: "Must be exactly 10 digits",
      },
      password: {
        required: "Please enter a password",
        minlength: "At least 6 characters",
      },
      confirm_password: {
        required: "Please confirm your password",
        equalTo: "Passwords do not match",
      },
      address: {
        required: "Please enter your address",
      },
      payment: {
        required: "Please select a payment method",
      },
    },

    errorElement: "div",
    errorPlacement: function (error, element) {
      error.addClass("text-danger mt-1");
      if (element.attr("type") === "radio") {
        error.insertAfter(element.closest(".form-radio"));
      } else {
        error.insertAfter(element);
      }
    },

    submitHandler: function (form) {
      form.submit();
    },
  });
});
