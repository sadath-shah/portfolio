<?php
include_once("navbar.php");
?>


<div id="welcome-section">
  <h1>Welcome to <span>Our School</span></h1>
  <p>Empowering students through quality education and opportunities.</p>
</div>


<div class="section-dark">
  <div class="container-content">
    <h2>Our Vision</h2>
    <p>
      At Our School, we strive to create a nurturing environment where students can grow intellectually,
      emotionally, and socially. We are committed to providing a holistic education that prepares our students
      for a bright future.
    </p>
  </div>
</div>


<div class="section-light">
  <div class="container-content">
    <h2>Why Choose Us?</h2>
    <p>
      We offer excellent academic programs, well-equipped facilities, and dedicated teachers who care deeply
      about student success. Join us to experience an educational journey like no other.
    </p>
  </div>
</div>


<footer>
  <p>
    2025 School Name. All Rights Reserved. For more information contact +91 9030145367 |
    Email: sadathshah01@gmail.com
  </p>
</footer>


<style>
  
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  body {
    font-family: Arial, sans-serif;
  }

  #welcome-section {
    background-image: url('https://images.unsplash.com/photo-1503676260728-1c00da094a0b');
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    height: 450px;
    color: white;
    text-align: center;
    padding-top: 150px;
    text-shadow: 1px 1px 4px black;
  }

  #welcome-section h1 {
    font-size: 3rem;
    margin-bottom: 20px;
  }

  #welcome-section span {
    color: #f8f9fa;
  }

  #welcome-section p {
    font-size: 1.3rem;
    margin-bottom: 0;
  }

  .section-dark {
    background-color: #000;
    color: white;
    padding: 80px 20px;
  }

  .section-light {
    background-color: #f8f9fa;
    color: #000;
    padding: 80px 20px;
  }

  .container-content {
    max-width: 1000px;
    margin: auto;
    text-align: center;
  }

  .container-content h2 {
    font-size: 2rem;
    font-weight: bold;
    margin-bottom: 20px;
  }

  .container-content p {
    font-size: 1.1rem;
    line-height: 1.7;
    max-width: 800px;
    margin: auto;
  }

  footer {
    background-color: rgb(236, 242, 247);
    color: black;
    text-align: center;
    padding: 15px;
    font-size: 0.95rem;
    box-shadow: 0 -2px 8px rgba(0, 0, 0, 0.05);
  }
</style>
