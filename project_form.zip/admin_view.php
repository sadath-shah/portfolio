<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

include 'admin_connect.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$stmt = $conn->prepare("SELECT * FROM student_registration_form WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "<h3 style='color: red; padding: 20px;'>No student found with ID $id</h3>";
    exit;
}

$student = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>View Student</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f8f9fa;
      padding-top: 40px;
    }

    .card {
      max-width: 800px;
      margin: auto;
    }

    .btn-back {
      display: flex;
      justify-content: center;
      margin-top: 40px;
      padding-bottom: 40px;
    }

    .profile-img {
      display: block;
      margin: 10px auto;
      border-radius: 10px;
      max-width: 150px;
      max-height: 150px;
      object-fit: cover;
    }
  </style>
</head>
<body>

  <div class="container">
    <div class="card shadow">
      <div class="card-body">
        <h2 class="text-center mb-4">Student Details (Admin View)</h2>
        <table class="table table-bordered">
          <tr><th>First Name</th><td><?= htmlspecialchars($student['firstname']) ?></td></tr>
          <tr><th>Last Name</th><td><?= htmlspecialchars($student['lastname']) ?></td></tr>
          <tr><th>DOB</th><td><?= htmlspecialchars($student['dob']) ?></td></tr>
          <tr><th>Gender</th><td><?= htmlspecialchars($student['gender']) ?></td></tr>
          <tr><th>Grade</th><td><?= htmlspecialchars($student['grade']) ?></td></tr>
          <tr><th>Languages</th><td><?= htmlspecialchars($student['languages']) ?></td></tr>
          <tr><th>Details 1</th><td><?= htmlspecialchars($student['details1']) ?></td></tr>
          <tr><th>Details 2</th><td><?= htmlspecialchars($student['details2']) ?></td></tr>
          <tr><th>Father's Name</th><td><?= htmlspecialchars($student['fathers_name']) ?></td></tr>
          <tr><th>Father's Qualification</th><td><?= htmlspecialchars($student['fathers_qualification']) ?></td></tr>
          <tr><th>Father's Email</th><td><?= htmlspecialchars($student['fathers_email']) ?></td></tr>
          <tr><th>Father's Phone</th><td><?= htmlspecialchars($student['fathers_phn_no']) ?></td></tr>
          <tr><th>Father's Occupation</th><td><?= htmlspecialchars($student['fathers_occupation']) ?></td></tr>
          <tr><th>Mother's Name</th><td><?= htmlspecialchars($student['mothers_name']) ?></td></tr>
          <tr><th>Mother's Qualification</th><td><?= htmlspecialchars($student['mothers_qualification']) ?></td></tr>
          <tr><th>Mother's Email</th><td><?= htmlspecialchars($student['mothers_email']) ?></td></tr>
          <tr><th>Mother's Phone</th><td><?= htmlspecialchars($student['mothers_phn_no']) ?></td></tr>
          <tr><th>Mother's Occupation</th><td><?= htmlspecialchars($student['mothers_occupation']) ?></td></tr>
          <tr>
            <th>Profile Image</th>
            <td>
              <?php if (!empty($student['profile_image'])): ?>
                <img src="uploads/<?= htmlspecialchars($student['profile_image']) ?>" alt="Profile Photo" class="profile-img">
              <?php else: ?>
                <span>No image uploaded</span>
              <?php endif; ?>
            </td>
          </tr>
          <tr><th>Address</th><td><?= htmlspecialchars($student['address']) ?></td></tr>
          <tr><th>Payment</th><td><?= htmlspecialchars($student['payment']) ?></td></tr>
        </table>
      </div>
    </div>

    <div class="btn-back">
      <a href="admin_student_records.php" class="btn btn-secondary">← Back to Student Records</a>
    </div>
  </div>

</body>
</html>
