<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "srf");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Data Table</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { margin: 40px; font-family: Arial, sans-serif; }
    .table-container { max-width: 95%; margin: auto; overflow-x: auto; }
    table { width: 100%; }
    thead th { white-space: nowrap; }
    .navbar-brand img {
      border-radius: 4px;
    }

    .navbar .btn {
      font-weight: 500;
    }

    .main-content {
      flex: 1;
      padding-top: 120px; 
    }

    .profile-img {
      width: 60px;
      height: 60px;
      object-fit: cover;
      border-radius: 8px;
    }
  </style>
</head>
<body>
  
<nav class="navbar navbar-expand-lg bg-white shadow-sm fixed-top">
  <div class="container-fluid px-4">
    <a class="navbar-brand d-flex align-items-center fw-bold" href="#">
      <img
        src="https://db0dce98.delivery.rocketcdn.me/en/files/2023/05/django1.jpg"
        alt="Logo"
        width="40"
        height="34"
        class="d-inline-block align-text-top me-2"
      />
      School Name
    </a>
    
    <div class="dropdown ms-auto">
      <a
        href="#"
        class="d-flex align-items-center text-decoration-none dropdown-toggle"
        id="userDropdown"
        data-bs-toggle="dropdown"
        aria-expanded="false"
      >
        <img
          src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
          alt="User Icon"
          width="32"
          height="32"
          class="rounded-circle"
        />
      </a>
      <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
        <li><a class="dropdown-item" href="edit.php">Update</a></li>
        <li><hr class="dropdown-divider"></li>
        <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
  <div class="table-container">
    <h3 class="mb-4 text-center">Student Data Table</h3>
    <table class="table table-bordered table-hover text-center align-middle">
      <thead class="table-light">
        <tr>
          <th>S.no</th><th>First Name</th><th>Last Name</th><th>DOB</th><th>Gender</th><th>Grade</th>
          <th>Languages</th><th>Details1</th><th>Details2</th><th>Image</th>
          <th>Father's Name</th><th>Father's Qualification</th><th>Father's Email</th><th>Father's Phone</th><th>Father's Occupation</th>
          <th>Mother's Name</th><th>Mother's Qualification</th><th>Mother's Email</th><th>Mother's Phone</th><th>Mother's Occupation</th>
          <th>Address</th><th>Payment</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $query = "SELECT * FROM student_registration_form";
        $query_run = mysqli_query($conn, $query);

        if (mysqli_num_rows($query_run) > 0) {
            foreach ($query_run as $row) {
                echo "<tr>";
                foreach ($row as $key => $value) {
                    if ($key === 'password') {
                        continue; 
                    } elseif ($key === 'profile_image') {
                        if (!empty($value)) {
                            echo "<td><img src='uploads/" . htmlspecialchars($value) . "' class='profile-img' alt='Profile'></td>";
                        } else {
                            echo "<td>No Image</td>";
                        }
                    } else {
                        echo "<td>" . htmlspecialchars($value) . "</td>";
                    }
                }
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='22'>No data found</td></tr>";
        }
        ?>
      </tbody>
    </table>
  </div>

  <div class="text-center mt-4">
    <a href="dashboard.php" class="btn btn-secondary">← Back to Dashboard</a>
  </div>

</body>
</html>
