-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 11, 2025 at 09:38 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `srf`
--

-- --------------------------------------------------------

--
-- Table structure for table `student_registration_form`
--

CREATE TABLE `student_registration_form` (
  `id` int(11) NOT NULL,
  `firstname` varchar(55) NOT NULL,
  `lastname` varchar(55) NOT NULL,
  `dob` varchar(15) NOT NULL,
  `gender` enum('Male','Female') NOT NULL,
  `grade` varchar(10) NOT NULL,
  `languages` varchar(55) NOT NULL,
  `details1` varchar(55) NOT NULL,
  `details2` varchar(55) NOT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `fathers_name` varchar(55) NOT NULL,
  `fathers_qualification` varchar(55) NOT NULL,
  `fathers_email` varchar(55) NOT NULL,
  `fathers_phn_no` varchar(10) NOT NULL,
  `fathers_occupation` varchar(55) NOT NULL,
  `mothers_name` varchar(55) NOT NULL,
  `mothers_qualification` varchar(55) NOT NULL,
  `mothers_email` varchar(55) NOT NULL,
  `mothers_phn_no` varchar(10) NOT NULL,
  `mothers_occupation` varchar(55) NOT NULL,
  `password` varchar(225) NOT NULL,
  `address` text NOT NULL,
  `payment` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_registration_form`
--

INSERT INTO `student_registration_form` (`id`, `firstname`, `lastname`, `dob`, `gender`, `grade`, `languages`, `details1`, `details2`, `profile_image`, `fathers_name`, `fathers_qualification`, `fathers_email`, `fathers_phn_no`, `fathers_occupation`, `mothers_name`, `mothers_qualification`, `mothers_email`, `mothers_phn_no`, `mothers_occupation`, `password`, `address`, `payment`) VALUES
(9, 'murat', 'test', '2025-06-25', 'Male', 'test', 'test', 'test', 'tes', '', 'test', 'test', 'tets@rsstt', '99999898', 'test', 'test', 'test', 'test@ytsss', '90900009', 'test', '$2y$08$435cWHiWqVPDRJlR9vpmWePw8Hte2bpk76f1kXMSkVo8GkSmf4E5u', 'test', 'cash'),
(14, 'test', 'test', '2021-10-27', 'Male', 'test', 'test', 'test', 'test', '', 'test', 'test', 'test', '902222222', 'test', 'test', 'test', 'test', '9000000', 'test', '', 'test', 'cash'),
(15, 'test', 'test', '2019-07-23', 'Male', 'test', 'test', 'test', 'test', '', 'tes', 'test', 'test@test', '900000000', 'test', 'test', 'test', 'test@test', '9000000000', 'test', 'test', 'test', 'check'),
(17, 'murat', 'shah', '2021-04-01', 'Male', 'A', 'cat language', 'nun', 'no one', '', 'Mohammed Sadath', 'student', 'sadathshah13@gmail.com', '9030145248', 'student', 'nun', 'nun', 'nun@nun', '900000', 'nun', 'Hayath@786', 'dont know', 'cash'),
(18, 'test', 'test', '2023-10-29', 'Male', 'test', 'test', 'test', 'test', '', 'test', 'test', 'test@gmail.com', '1234567888', 'test', 'test', 'test', 'test@gmail.com', '1234567889', 'test', 'test', 'test', 'card'),
(19, 'test', 'test', '2025-12-31', 'Female', 'test', 'test', 'test', 'test', '', 'test', 'test', 'test@test.com', '1234567890', 'test', 'test', 'test', 'test@test.com', '1234567890', 'test', 'test12345', 'test', 'cash'),
(20, 'test test', 'test', '2025-06-23', 'Female', 'test', 'test', 'test', 'test', '', 'test', 'test', 'test@test.com', '1234567889', 'test', 'test', 'test', 'test@test.com', '1234567890', 'test', 'test1234', 'test', 'check'),
(21, 'test', 'test', '2023-10-28', 'Male', 'test', 'test', 'test', 'test', '', 'test', 'test', 'test@test.com', '1234567890', 'test', 'test', 'test', 'test', '1234567890', 'test', 'test', 'test', 'check'),
(22, 'test', 'test', '2023-11-29', 'Female', 'test', 'test', 'test', 'test', '', 'test', 'test', 'test@test', '1234567890', 'test', 'test', 'test', 'test', '12345678', 'test', 'test', 'test', 'check'),
(23, 'sadath', 'shah 12', '2025-06-09', 'Male', 'test', 'test', 'test', 'test', '', 'test', 'test', 'test@gmail.com', '1234567890', 'test', 'test', 'test', 'test@gmail.com', '1234567890', 'test', 'test@12345', 'test', 'check'),
(25, 'dsfsdfffsfsd', 'gfdsgfdg', '2025-07-13', 'Male', 'fsdfsdffer', 'wrewerewr', 'ewwerewr', 'ewerw', '', 'ewrewreq', 'ewrwe', 'bharahkiran@gmail.com', '7013897004', 'father', 'mother', 'teacher', 'khasim.shah@gmail.com', '9848145248', 'test', '123456', '5-7-67 Housing Board Colony, Pakabanda Bazar , khammam', 'check'),
(26, 'test', 'test', '2020-09-28', 'Male', 'A', 'test', 'test', 'test', '', 'test', 'test', 'test@test.com', '1234567890', 'test', 'test', 'test', 'test@test.com', '1234567890', 'test', '$2y$08$2VCuNayZ.bHMa/7xiqjg9.uMJJpQ.sXg7SDgWn8rwUxvbQro', 'test', 'cash'),
(29, 'Khasimshah', 'shah', '2025-07-07', 'Male', 'test', 'test', 'test', 'test', '', 'khasim', 'test', 'khasim.shah@gmail.com', '9848145248', 'test', 'mateen', '23432', 'khasim.shah@gmail.com', '9848145248', 'test', '$2y$10$.PVJ4ErDeGnXkPKWRGgwY.RgX/SvJ0AiFzS1Qd9DchjECFsu', '5-7-67 Housing Board Colony, Pakabanda Bazar , khammam', 'check'),
(30, 'Khasimshah', 'shah', '2025-07-23', 'Male', 'test', 'test', 'test', 'test', '1751434399_pexels-anastasiya-gepp-654466-1462630.jpg', 'test', 'test', 'khasim.shah@gmail.com', '9848145248', 'test', 'test', 'test', 'test@gmail.com', '9848145248', 'tecaher', '$2y$10$mXaAXoTX9Ym83.wm.sEAYOXkY2C5iFW3Vxe/pZmNDJQ6ZK.i', '5-7-67 Housing Board Colony, Pakabanda Bazar , khammam', 'check'),
(34, 'Mohammed', 'Sadath', '2005-02-17', 'Male', 'test', 'test', 'test', 'test', '1751611415_pexels-anastasiya-gepp-654466-1462630.jpg', 'test', 'test', 'test@test.com', '1234567890', 'test', 'test', 'test', 'test@gmail.com', '1234567890', 'test', '$2y$08$IbpyYb4wE.CMHMJa4sJXeOIX4NnWkdyfkBAtTMtZwmDWfJ2MIgTmS', 'test', 'check'),
(35, 'sithwath', 'shah', '2021-09-29', 'Male', 'test', 'test', 'test', 'test', '1751622196_pexels-anastasiya-gepp-654466-1462630.jpg', 'test', 'test', 'test@test.com', '1234567890', 'test', 'test', 'test', 'test@gmail.com', '1234567890', 'test', '$2y$08$435cWHiWqVPDRJlR9vpmWePw8Hte2bpk76f1kXMSkVo8GkSmf4E5u', 'test', 'cash'),
(36, 'athar', 'mohammad', '1990-02-28', 'Male', '10', 'english', '12', '12', '1751700925_Screenshot 2025-05-21 162134.png', 'test', 'test', 'test@gmail.com', '9876543212', 'testw', 'test', 'test', 'test@gmail.com', '1234567899', 'test', '$2y$10$UetC21VVIQbXfMP3R2aQm.4yO7gOo0Icr1p5Uipe8yOvk5.FRW2JO', 'test', 'cash');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student_registration_form`
--
ALTER TABLE `student_registration_form`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student_registration_form`
--
ALTER TABLE `student_registration_form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
