<?php
session_start();
include 'admin_connect.php';


if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}


$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    die("Invalid admin ID.");
}


if ($id == $_SESSION['admin_id']) {
    die("You cannot delete yourself!");
}


$stmt = $conn->prepare("SELECT * FROM admin WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 0) {
    die("Admin not found.");
}
$stmt->close();


$delete = $conn->prepare("DELETE FROM admin WHERE id = ?");
$delete->bind_param("i", $id);

if ($delete->execute()) {
    header("Location: admin_data.php?deleted=1");
    exit();
} else {
    echo "Failed to delete admin.";
}

$delete->close();
$conn->close();
?>
