<?php
session_start();
if (!isset($_SESSION['username']) || !isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

$profileImageFilename = !empty($_SESSION['pfp']) ? htmlspecialchars($_SESSION['pfp']) : null;
$profileImagePath = $profileImageFilename ? "uploads/" . $profileImageFilename : 'https://cdn-icons-png.flaticon.com/512/3135/3135715.png';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body {
      margin: 0;
      padding: 0;
      background-image: url('https://elements-resized.envatousercontent.com/envato-dam-assets-production/EVA/TRX/a4/bc/2b/c1/35/v1_E10/E10A3Q1Y.jpg?w=1400&cf_fit=scale-down&mark-alpha=18&mark=https%3A%2F%2Felements-assets.envato.com%2Fstatic%2Fwatermark4.png&q=85&format=auto&s=b0fc52b3104e68f9cd606f64ccdc239db73b8ccb12e021bb606243ecbea6772c');
      background-size: cover;
      background-repeat: no-repeat;
      background-attachment: fixed;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    .navbar-brand img {
      border-radius: 4px;
    }

    .navbar .btn {
      font-weight: 500;
    }

    .main-content {
      flex: 1;
      padding-top: 120px;
    }

    .dashboard-btn {
      padding: 40px;
      font-size: 18px;
      border-radius: 12px;
      width: 100%;
      height: 100%;
    }

    footer {
      background-color: rgb(236, 242, 247);
      color: black;
      text-align: center;
      padding: 15px;
      margin-top: auto;
      box-shadow: 0 -2px 8px rgba(0, 0, 0, 0.05);
    }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg bg-white shadow-sm fixed-top">
  <div class="container-fluid px-4">
    <a class="navbar-brand d-flex align-items-center fw-bold" href="#">
      <img
        src="https://db0dce98.delivery.rocketcdn.me/en/files/2023/05/django1.jpg"
        alt="Logo"
        width="40"
        height="34"
        class="d-inline-block align-text-top me-2"
      />
      School Name
    </a>

    <div class="ms-auto d-flex align-items-center">
      <span class="me-3">Hello, <?= htmlspecialchars($_SESSION['username']) ?>!</span>

      <div class="dropdown">
        <a
          href="#"
          class="d-flex align-items-center text-decoration-none dropdown-toggle"
          id="userDropdown"
          data-bs-toggle="dropdown"
          aria-expanded="false"
        >
          <img
            src="<?= $profileImagePath ?>"
            alt="Profile Image"
            width="40"
            height="40"
            class="rounded-circle me-3"
            style="object-fit: cover;"
            onerror="this.onerror=null;this.src='https://cdn-icons-png.flaticon.com/512/3135/3135715.png';"
          />
        </a>

        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
          <li>
            <a class="dropdown-item" href="edit.php?id=<?= $_SESSION['id'] ?>">Update</a>
          </li>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
        </ul>
      </div>
    </div>
  </div>
</nav>

<div class="container main-content text-center">
  <h2 class="mb-4 text-black">Welcome to the Dashboard</h2>

  <div class="row justify-content-center g-4">
    <div class="col-md-4">
      <a href="buttons.php" class="btn btn-primary dashboard-btn">Exam Results</a>
    </div>
    <div class="col-md-4">
      <a href="#" class="btn btn-secondary dashboard-btn">Student Attendance</a>
    </div>
    <div class="col-md-4">
      <a href="notice_board.php" class="btn btn-success dashboard-btn">Notice Board</a>
    </div>
  </div>
</div>

<footer>
  <p>School Name. All Rights Reserved. For more information, contact +91 9030145367<br>
  Email: sadathshah01@gmail.com</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
