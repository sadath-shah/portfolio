<?php
include 'admin_connect.php';
session_start();


$adminName = $_SESSION['adminName'] ?? "Admin";
$profileImagePath = $_SESSION['profileImagePath'] ?? "default-profile.png";

$secret_key = "Murat@786"; 
$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $entered_key = $_POST['access_key'] ?? '';

    if ($entered_key !== $secret_key) {
        $errors[] = "Invalid access key.";
    } else {
        $first_name = trim($_POST['first_name']);
        $username = trim($_POST['username']);
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];

        if (empty($first_name) || empty($username) || empty($password) || empty($confirm_password)) {
            $errors[] = "All fields are required.";
        } elseif ($password !== $confirm_password) {
            $errors[] = "Passwords do not match.";
        } else {
            $stmt = $conn->prepare("SELECT username FROM admin WHERE username = ?");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows > 0) {
                $errors[] = "Username already taken.";
            } else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("INSERT INTO admin (first_name, username, password) VALUES (?, ?, ?)");
                $stmt->bind_param("sss", $first_name, $username, $hashed_password);

                if ($stmt->execute()) {
                    echo "<script>alert('Admin registered successfully'); window.location.href='admin_login.php';</script>";
                    exit();
                } else {
                    $errors[] = "Error: " . $stmt->error;
                }
            }

            $stmt->close();
        }
    }

    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Admin Registration</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body, html {
      height: 115%;
      margin: 0;
      background-image: url('https://images.pexels.com/photos/4144221/pexels-photo-4144221.jpeg');
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
      font-family: Arial, sans-serif;
    }

    .card {
      background-color: rgba(255, 255, 255, 0.97);
      border-radius: 15px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
    }

    .form-control {
      border-radius: 8px;
      font-size: 14px;
      padding: 10px;
    }

    .form-label {
      font-weight: 600;
      font-size: 14px;
    }

    .btn-primary {
      border-radius: 8px;
      font-weight: bold;
      padding: 10px;
    }

    footer {
      background-color: rgb(236, 242, 247);
      color: black;
      text-align: center;
      padding: 19px;
      font-size: 0.95rem;
      box-shadow: 0 -2px 8px rgba(0, 0, 0, 0.05);
      margin-top: 50px;
    }

    @media (max-width: 768px) {
      .container {
        padding: 15px;
      }

      .col-md-6.offset-md-3 {
        margin: 0 auto;
        width: 100%;
      }
    }
  </style>
</head>

<body>


<nav class="navbar navbar-expand-lg bg-white shadow-sm fixed-top">
  <div class="container-fluid px-4">
    <a class="navbar-brand d-flex align-items-center fw-bold" href="#">
      <img
        src="https://db0dce98.delivery.rocketcdn.me/en/files/2023/05/django1.jpg"
        alt="Logo"
        width="40"
        height="34"
        class="d-inline-block align-text-top me-2"
      />
      School Name
    </a>
    <div class="ms-auto d-flex align-items-center">
      <span class="me-3">Hello, <?php echo htmlspecialchars($adminName); ?>!</span>
      <div class="dropdown">
        <a
          href="#"
          class="d-flex align-items-center text-decoration-none dropdown-toggle"
          id="userDropdown"
          data-bs-toggle="dropdown"
          aria-expanded="false"
        >
          <img
            src="<?= htmlspecialchars($profileImagePath) ?>"
            alt="Profile Image"
            width="40"
            height="40"
            class="rounded-circle me-3"
            style="object-fit: cover;"
          />
        </a>
        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
          <li><a class="dropdown-item" href="admin_form.php">Add New Admin</a></li>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
        </ul>
      </div>
    </div>
  </div>
</nav>


<div class="container mt-5 pt-5">
  <div class="col-md-6 offset-md-3">
    <div class="card shadow p-4">
      <h3 class="text-center mb-4">Admin Registration</h3>
      <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
          <?php foreach ($errors as $error): ?>
            <div><?= htmlspecialchars($error) ?></div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>

      <form method="POST">
        <div class="mb-3">
          <label class="form-label">Secret Access Key</label>
          <input type="text" class="form-control" name="access_key" required>
        </div>
        <div class="mb-3">
          <label class="form-label">First Name</label>
          <input type="text" class="form-control" name="first_name" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Username</label>
          <input type="text" class="form-control" name="username" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Password</label>
          <input type="password" class="form-control" name="password" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Confirm Password</label>
          <input type="password" class="form-control" name="confirm_password" required>
        </div>
        <button type="submit" class="btn btn-primary w-100">Register</button>

        <div class="text-center mt-3">
          
          <a href="admin_dashboard.php" class="btn btn-outline-secondary btn-sm">Back to dashboard</a>
        </div>
      </form>
    </div>
  </div>
</div>


<footer>
  <p>
    2025 School Name. All Rights Reserved. For more information contact +91 9030145367 |
    Email: sadathshah01@gmail.com
  </p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
