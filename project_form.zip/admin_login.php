<?php
session_start();
include 'admin_connect.php';
include 'navbar.php';

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    if (!$conn) {
        die("Connection object is invalid.");
    }

    $stmt = $conn->prepare("SELECT id, first_name, password FROM admin WHERE username = ?");
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows == 1) {
        $stmt->bind_result($id, $first_name, $hashed_password);
        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {
            $_SESSION['admin_id'] = $id;
            $_SESSION['username'] = $username;
            $_SESSION['first_name'] = $first_name; // ✅ Now you can safely use this everywhere
            header("Location: admin_dashboard.php");
            exit();
        } else {
            $error = "Invalid password.";
        }
    } else {
        $error = "Invalid username.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Admin Portal</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body {
      font-family: Arial, sans-serif;
      background-image: url('https://images.pexels.com/photos/1181358/pexels-photo-1181358.jpeg');
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
      margin: 0;
      padding: 0;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    .container {
      flex: 1;
    }

    .login-card {
      width: 100%;
      max-width: 400px;
      background-color: rgba(255, 255, 255, 0.95);
      padding: 30px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
      border-radius: 12px;
      border: 1px solid #ccc;
    }

    .form-control {
      margin-bottom: 15px;
    }

    .btn-primary {
      font-weight: bold;
    }

    .alert {
      font-size: 14px;
    }

    footer {
      background-color: rgb(236, 242, 247);
      text-align: center;
      padding: 25px;
      font-size: 1rem;
      color: rgb(40, 41, 43);
      box-shadow: 0 -2px 6px rgba(0, 0, 0, 0.05);
    }
  </style>
</head>
<body>

<div class="container d-flex justify-content-center align-items-center min-vh-100">
  <div class="login-card">
    <h2 class="text-center mb-4">Admin Portal</h2>

    <?php if (!empty($error)) : ?>
      <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form method="POST" action="">
      <label for="username" class="form-label">Enter Username:</label>
      <input type="text" name="username" class="form-control" placeholder="Enter Here" required>

      <label for="password" class="form-label">Enter Password:</label>
      <input type="password" name="password" class="form-control" placeholder="Enter Here" required>

      <div class="d-grid mt-3">
        <button type="submit" class="btn btn-primary">Login</button>
      </div>
    </form>

    <div class="text-center mt-3">
      <a href="login.php" class="link-primary">IF STUDENT LOGIN HERE</a>
    </div>
  </div>
</div>

<footer>
  2025 School Name. All Rights Reserved. Contact: +91 9030145367 | Email: sadathshah01@gmail.com
</footer>

</body>
</html>
