<?php
session_start();
include_once("navbar.php"); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Student Login</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  
  <style>
    body {
      font-family: Arial, sans-serif;
      background-image: url('https://images.unsplash.com/photo-1571260899304-425eee4c7efc?auto=format&fit=crop&w=1740&q=80');
      background-size: cover;
      background-repeat: no-repeat;
      background-position: center;
      background-attachment: fixed;
      margin: 0;
      padding: 0;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    .container {
      flex: 1;
    }

    .login-card {
      width: 100%;
      max-width: 400px;
      background-color: rgba(255, 255, 255, 0.95);
      padding: 30px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
      border-radius: 12px;
      border: 1px solid #ccc;
    }

    .form-control {
      margin-bottom: 15px;
    }

    footer {
      background-color: rgb(236, 242, 247);
      text-align: center;
      padding: 25px;
      font-size: 1rem;
      color: rgb(40, 41, 43);
      box-shadow: 0 -2px 6px rgba(0, 0, 0, 0.05);
    }
  </style>
</head>
<body>

<div class="container d-flex justify-content-center align-items-center min-vh-100">
  <div class="login-card">
    <h2 class="text-center mb-4">Student Portal</h2>
    <form action="submit_login.php" method="post">
      <label for="username" class="form-label">Enter Username:</label>
      <input type="text" placeholder="Enter Here" class="form-control" name="login" id="username" required>
      <div class="error"></div>

      <label for="password" class="form-label">Enter Password:</label>
      <input type="password" placeholder="Enter Here" class="form-control" name="password" id="password" required>
      <div class="error"></div>

      <div class="d-grid mt-3">
        <button type="submit" class="btn btn-primary">Login</button>
      </div>
    </form>

    <div class="text-center mt-4">
      <p>Don't have an account?</p>
      <a href="form.php" class="btn btn-outline-secondary">Create Account</a>
    </div>

    <div class="text-center mt-3">
      <a href="admin_login.php" class="link-primary">IF ADMIN LOGIN HERE</a>
    </div>
  </div>
</div>

<footer>
  2025 School Name. All Rights Reserved. Contact: +91 9030145367 | Email: sadathshah01@gmail.com
</footer>

</body>
</html>
