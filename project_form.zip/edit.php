 <?php
session_start();

if (!isset($_SESSION['username']) ) {
    header("Location: login.php");
    exit();
} 
$conn = new mysqli('localhost', 'root', '', 'srf');

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$stmt = $conn->prepare("SELECT * FROM student_registration_form WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
  echo "No student found!";
  exit;
}

$student = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $firstname = $_POST['firstname'];
  $lastname = $_POST['lastname'];
  $dob = $_POST['dob'];
  $gender = $_POST['gender'];
  $grade = $_POST['grade'];
  $languages = $_POST['languages'];
  $details1 = $_POST['details1'];
  $details2 = $_POST['details2'];

  $fathers_name = $_POST['fathers_name'];
  $fathers_qualification = $_POST['fathers_qualification'];
  $fathers_email = $_POST['fathers_email'];
  $fathers_phn_no = $_POST['fathers_phn_no'];
  $fathers_occupation = $_POST['fathers_occupation'];

  $mothers_name = $_POST['mothers_name'];
  $mothers_qualification = $_POST['mothers_qualification'];
  $mothers_email = $_POST['mothers_email'];
  $mothers_phn_no = $_POST['mothers_phn_no'];
  $mothers_occupation = $_POST['mothers_occupation'];

  $password = $_POST['password'];
  $address = $_POST['address'];
  $payment = $_POST['payment'];

  $stmt = $conn->prepare("UPDATE student_registration_form 
    SET firstname=?, lastname=?, dob=?, gender=?, grade=?, languages=?, details1=?, details2=?, 
        fathers_name=?, fathers_qualification=?, fathers_email=?, fathers_phn_no=?, fathers_occupation=?, 
        mothers_name=?, mothers_qualification=?, mothers_email=?, mothers_phn_no=?, mothers_occupation=?, 
        password=?, address=?, payment=? 
    WHERE id=?");

  $stmt->bind_param("sssssssssssssssssssssi", 
    $firstname, $lastname, $dob, $gender, $grade, $languages, $details1, $details2,
    $fathers_name, $fathers_qualification, $fathers_email, $fathers_phn_no, $fathers_occupation,
    $mothers_name, $mothers_qualification, $mothers_email, $mothers_phn_no, $mothers_occupation,
    $password, $address, $payment, $id);

  $stmt->execute();

  header("Location: buttons.php");
  exit;
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Edit Student</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">
  <div class="container">
    <h2>Edit Student</h2>
    <form method="POST">
      <div class="mb-3"><label>First Name</label><input type="text" name="firstname" class="form-control" value="<?= $student['firstname'] ?>" required></div>
      <div class="mb-3"><label>Last Name</label><input type="text" name="lastname" class="form-control" value="<?= $student['lastname'] ?>" required></div>
      <div class="mb-3"><label>Date of Birth</label><input type="date" name="dob" class="form-control" value="<?= $student['dob'] ?>" required></div>
      <div class="mb-3"><label>Gender</label><input type="text" name="gender" class="form-control" value="<?= $student['gender'] ?>" required></div>
      <div class="mb-3"><label>Grade</label><input type="text" name="grade" class="form-control" value="<?= $student['grade'] ?>" required></div>
      <div class="mb-3"><label>Languages</label><input type="text" name="languages" class="form-control" value="<?= $student['languages'] ?>" required></div>
      <div class="mb-3"><label>Details 1</label><input type="text" name="details1" class="form-control" value="<?= $student['details1'] ?>"></div>
      <div class="mb-3"><label>Details 2</label><input type="text" name="details2" class="form-control" value="<?= $student['details2'] ?>"></div>

      
      <div class="mb-3"><label>Father's Name</label><input type="text" name="fathers_name" class="form-control" value="<?= $student['fathers_name'] ?>" required></div>
      <div class="mb-3"><label>Father's Qualification</label><input type="text" name="fathers_qualification" class="form-control" value="<?= $student['fathers_qualification'] ?>"></div>
      <div class="mb-3"><label>Father's Email</label><input type="email" name="fathers_email" class="form-control" value="<?= $student['fathers_email'] ?>"></div>
      <div class="mb-3"><label>Father's Phone No</label><input type="text" name="fathers_phn_no" class="form-control" value="<?= $student['fathers_phn_no'] ?>"></div>
      <div class="mb-3"><label>Father's Occupation</label><input type="text" name="fathers_occupation" class="form-control" value="<?= $student['fathers_occupation'] ?>"></div>

      
      <div class="mb-3"><label>Mother's Name</label><input type="text" name="mothers_name" class="form-control" value="<?= $student['mothers_name'] ?>"></div>
      <div class="mb-3"><label>Mother's Qualification</label><input type="text" name="mothers_qualification" class="form-control" value="<?= $student['mothers_qualification'] ?>"></div>
      <div class="mb-3"><label>Mother's Email</label><input type="email" name="mothers_email" class="form-control" value="<?= $student['mothers_email'] ?>"></div>
      <div class="mb-3"><label>Mother's Phone No</label><input type="text" name="mothers_phn_no" class="form-control" value="<?= $student['mothers_phn_no'] ?>"></div>
      <div class="mb-3"><label>Mother's Occupation</label><input type="text" name="mothers_occupation" class="form-control" value="<?= $student['mothers_occupation'] ?>"></div>

      
      <div class="mb-3"><label>Password</label><input type="password" name="password" class="form-control" value="<?= $student['password'] ?>" required></div>
      <div class="mb-3"><label>Address</label><input type="text" name="address" class="form-control" value="<?= $student['address'] ?>"></div>
      <div class="mb-3"><label>Payment Type</label><input type="text" name="payment" class="form-control" value="<?= $student['payment'] ?>"></div>

      <button type="submit" class="btn btn-success">Update</button>
      <a href="data.php" class="btn btn-secondary">Cancel</a>
    </form><br>
    <a href="buttons.php" class="btn btn-secondary">← Back to Data Table</a>
    
  </div>
</body>
</html>
