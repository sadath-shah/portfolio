<?php include_once("navbar.php"); ?>

<div class="about-container">
  <h1>About Us</h1>
  <p>
    Welcome to Our School! Established in 1995, we are committed to nurturing young minds and inspiring future leaders...
  </p>
  <p>
    With modern classrooms, passionate teachers, and a diverse range of extracurricular activities...
  </p>
  <p>
    Join our growing family, and let's walk the path of knowledge and discovery together.
  </p>
</div>

<footer>
  <p>
    2025 School Name. All Rights Reserved. For more information contact +91 9030145367 | E.mail: sadathshah01@gmail.com
  </p>
</footer>

<style>
  body {
    font-family: 'Segoe UI', sans-serif;
    background-image: url('https://images.unsplash.com/photo-1571260899304-425eee4c7efc');
    background-size: cover;
    background-attachment: fixed;
    background-repeat: no-repeat;
    background-position: center;
    margin: 0;
    padding-top: 80px;
    color: #333;
  }

  .about-container {
    background-color: rgba(255, 255, 255, 0.95);
    max-width: 900px;
    margin: 40px auto;
    padding: 40px;
    border-radius: 15px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
  }

  .about-container h1 {
    font-weight: bold;
    color: #004080;
    margin-bottom: 25px;
  }

  .about-container p {
    font-size: 1.1rem;
    line-height: 1.7;
    color: #444;
  }

  footer {
    background-color: rgb(236, 242, 247);
    color: black;
    text-align: center;
    padding: 15px;
    margin-top: 122px;
    
  }
</style>
