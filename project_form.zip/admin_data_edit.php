<?php
session_start();
include 'admin_connect.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}


$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id <= 0) {
    die("Invalid admin ID.");
}


$stmt = $conn->prepare("SELECT * FROM admin WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();

if (!$admin) {
    die("Admin not found.");
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $first_name = trim($_POST['first_name']);
    $password = trim($_POST['password']);

    
    if (!empty($password)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $update = $conn->prepare("UPDATE admin SET username = ?, first_name = ?, password = ? WHERE id = ?");
        $update->bind_param("sssi", $username, $first_name, $hashed_password, $id);
    } else {
        $update = $conn->prepare("UPDATE admin SET username = ?, first_name = ? WHERE id = ?");
        $update->bind_param("ssi", $username, $first_name, $id);
    }

    if ($update->execute()) {
        $_SESSION['first_name'] = $first_name;
        $_SESSION['username'] = $username;
        header("Location: admin_data.php");
        exit();
    } else {
        echo "<div class='alert alert-danger'>Update failed.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">

<div class="container">
  <h2 class="mb-4">Edit Admin Details</h2>
  <form method="POST">
    <div class="mb-3">
      <label for="username" class="form-label">Username</label>
      <input type="text" name="username" class="form-control" value="<?= htmlspecialchars($admin['username']); ?>" required>
    </div>
    <div class="mb-3">
      <label for="first_name" class="form-label">First Name</label>
      <input type="text" name="first_name" class="form-control" value="<?= htmlspecialchars($admin['first_name']); ?>" required>
    </div>
    <div class="mb-3">
      <label for="password" class="form-label">New Password (leave blank to keep current)</label>
      <input type="password" name="password" class="form-control">
    </div>
    <button type="submit" class="btn btn-primary">Update Admin</button>
    <a href="admin_data.php" class="btn btn-secondary">Cancel</a>
  </form>
</div>

</body>
</html>
