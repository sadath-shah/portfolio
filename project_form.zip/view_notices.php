<?php
include 'notice_db.php';

$sql = "SELECT * FROM notices WHERE status = 'Active' ORDER BY created_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>View Notices</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container mt-5">
    <h2 class="mb-4 text-center">Notice Board</h2>

    <?php if ($result->num_rows > 0): ?>
      <table class="table table-striped table-bordered">
        <thead class="table-dark">
          <tr>
            <th>S.No.</th>
            <th>Title</th>
            <th>Message</th>
            <th>Created At</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $sno = 1;
          while ($row = $result->fetch_assoc()):
          ?>
            <tr>
              <td><?php echo $sno++; ?></td>
              <td><?php echo htmlspecialchars($row['title']); ?></td>
              <td><?php echo nl2br(htmlspecialchars($row['content'])); ?></td>
              <td><?php echo $row['created_at']; ?></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    <?php else: ?>
      <p class="text-center">No notices available.</p>
    <?php endif; ?>

    <div class="text-center mt-4">
      <a href="dashboard.php" class="btn btn-secondary">← Back to Dashboard</a>
    </div>
  </div>
</body>
</html>
