<?php
session_start();
$conn = new mysqli("localhost", "root", "", "srf");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $login = $_POST['login'];
    $password = $_POST['password'];

    // Debug query display (for dev only, don’t use in prod)
    // echo "DEBUG QUERY: SELECT * FROM student_registration_form WHERE firstname = '$login'<br>";
    // echo "DEBUG QUERY: SELECT * FROM student_registration_form WHERE password = '$password'<br>";
    // exit;

   
    $stmt = $conn->prepare("SELECT * FROM student_registration_form WHERE firstname = ?");
    $stmt->bind_param("s", $login);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        if (password_verify($password, $row['password'])) {
            $_SESSION['id'] = $row['id'];
            $_SESSION['username'] = $row['firstname'];
            $_SESSION['pfp'] = $row['profile_image'];
            
            header("Location: dashboard.php");
            exit();
        } else {
            echo "<script>alert('Invalid password'); window.location.href='login.php';</script>";
            exit();
        }
    } else {
        echo "<script>alert('User not found'); window.location.href='login.php';</script>";
        exit();
    }
}
?>
