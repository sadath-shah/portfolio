<?php
include 'notice_db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = intval($_POST['id']);
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    $status = $_POST['status'];

    if ($id > 0 && !empty($title) && !empty($content) && !empty($status)) {
        $stmt = $conn->prepare("UPDATE notices SET title = ?, content = ?, status = ? WHERE id = ?");
        $stmt->bind_param("sssi", $title, $content, $status, $id);

        if ($stmt->execute()) {
            echo "<script>alert('Notice updated successfully!'); window.location.href = 'notice_board.php';</script>";
        } else {
            echo "Error updating notice: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Invalid data.";
    }

    $conn->close();
} else {
    echo "Invalid request.";
}
?>
