<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

include 'admin_connect.php';

$query = "SELECT * FROM student_registration_form";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Student Records</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

  <style>
    body {
      font-family: Arial, sans-serif;
      padding-top: 80px;
      background-color: #f9f9f9;
    }

    .navbar-brand img {
      border-radius: 4px;
    }

    .table-container {
      max-width: 96%;
      margin: auto;
      overflow-x: auto;
    }

    table th, table td {
      white-space: nowrap;
      vertical-align: middle;
    }

    .back-btn {
      margin: 20px 0;
    }
  </style>
</head>
<body>

<?php
$adminName = htmlspecialchars($_SESSION['first_name']);
$profileImagePath = 'https://cdn-icons-png.flaticon.com/512/3135/3135715.png';
?>

<nav class="navbar navbar-expand-lg bg-white shadow-sm fixed-top">
  <div class="container-fluid px-4">
    <a class="navbar-brand d-flex align-items-center fw-bold" href="#">
      <img src="https://db0dce98.delivery.rocketcdn.me/en/files/2023/05/django1.jpg" alt="Logo" width="40" height="34" class="d-inline-block align-text-top me-2" />
      School Name
    </a>

    <div class="ms-auto d-flex align-items-center">
      <span class="me-3">Hello, <?= $adminName ?>!</span>

      <div class="dropdown">
        <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
          <img src="<?= $profileImagePath ?>" alt="Profile Image" width="40" height="40" class="rounded-circle me-3" style="object-fit: cover;" />
        </a>

        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
          <li><a class="dropdown-item" href="admin_form.php">Add New Admin</a></li>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
        </ul>
      </div>
    </div>
  </div>
</nav>

<div class="table-container mt-4">
  <h3 class="text-center mb-4">All Student Records</h3>
  <table class="table table-bordered table-hover text-center align-middle">
    <thead class="table-dark">
      <tr>
        <th>S.No</th>
        <th>First Name</th>
        <th>Second Name</th>
        <th>DOB</th>
        <th>Gender</th>
        <th>Grade</th>
        <th>Languages</th>
        <th>Details 1</th>
        <th>Details 2</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php
      if ($result && $result->num_rows > 0) {
          $serial = 1;
          while ($row = $result->fetch_assoc()) {
              echo "<tr>
                  <td>" . $serial . "</td>
                  <td>" . htmlspecialchars($row['firstname']) . "</td>
                  <td>" . htmlspecialchars($row['lastname']) . "</td>
                  <td>" . htmlspecialchars($row['dob']) . "</td>
                  <td>" . htmlspecialchars($row['gender']) . "</td>
                  <td>" . htmlspecialchars($row['grade']) . "</td>
                  <td>" . htmlspecialchars($row['languages']) . "</td>
                  <td>" . htmlspecialchars($row['details1']) . "</td>
                  <td>" . htmlspecialchars($row['details2']) . "</td>
                  <td>
                      <a href='admin_view.php?id=" . $row['id'] . "' class='text-primary me-2' title='View'><i class='fas fa-eye'></i></a>
                      <a href='admin_edit.php?id=" . $row['id'] . "' class='text-warning me-2' title='Edit'><i class='fas fa-edit'></i></a>
                      <a href='admin_delete.php?id=" . $row['id'] . "' class='text-danger' title='Delete' onclick='return confirm(\"Are you sure you want to delete this record?\")'><i class='fas fa-trash-alt'></i></a>
                  </td>
              </tr>";
              $serial++;
          }
      } else {
          echo "<tr><td colspan='10' class='text-center'>No student records found.</td></tr>";
      }
      ?>
    </tbody>
  </table>
</div>

<div class="text-center back-btn">
  <a href="admin_dashboard.php" class="btn btn-secondary">← Back to Dashboard</a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
